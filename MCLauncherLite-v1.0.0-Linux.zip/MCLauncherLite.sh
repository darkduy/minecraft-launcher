#!/bin/bash
echo "=============================="
echo " MC Launcher Lite v1.0.0"
echo " Tối ưu cho máy yếu"
echo "=============================="

# Kiểm tra Java
if ! command -v java &> /dev/null; then
    echo "[LỖI] Không tìm thấy Java! Cài Java 17+:"
    echo "  Ubuntu/Debian: sudo apt install openjdk-17-jre"
    echo "  Fedora/RHEL:   sudo dnf install java-17-openjdk"
    exit 1
fi

JAVA_VER=$(java -version 2>&1 | head -1 | cut -d'"' -f2)
echo "[INFO] Java: $JAVA_VER"

# Chạy launcher
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
java -jar "$SCRIPT_DIR/MCLauncherLite.jar" "$@"
