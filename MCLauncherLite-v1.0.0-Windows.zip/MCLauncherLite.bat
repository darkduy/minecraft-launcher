@echo off
title MC Launcher Lite
echo ============================
echo  MC Launcher Lite v1.0.0
echo  Toi uu cho may yeu
echo ============================
echo.

:: Kiem tra Java
java -version >nul 2>&1
if errorlevel 1 (
    echo [LOI] Khong tim thay Java! Hay cai Java 17+ tu java.com
    pause
    exit /b 1
)

:: Lay version Java
for /f tokens^=3^ delims^=.^" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do (
    set JAVA_VER=%%v
    goto :gotver
)
:gotver

echo [INFO] Java: %JAVA_VER%
echo [INFO] Khoi dong launcher...
echo.

:: Chay launcher
java -jar "%~dp0MCLauncherLite.jar" %*

if errorlevel 1 (
    echo.
    echo [LOI] Launcher gap su co. Nhan phim bat ky de thoat.
    pause
)
